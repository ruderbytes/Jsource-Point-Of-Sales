<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <?
        $meta=Setapp::Model()->findAll(array(
        'select'=>'*',
        'condition'=>'id_app=:app',
        'params'=>array(':app'=>1),
        ));
        foreach($meta as $dat):
        ?>
        <meta name="language" content="<?=$dat->language?>" />
        <meta name="description" content="<?=$dat->website_desc?>"/>
        <meta name="author" content="<?=$dat->author?>"/>
        <link href='<? echo Yii::app()->request->baseUrl.'/images/files_img/'.$dat->favicon;?>' rel='SHORTCUT ICON'/>
        <?endforeach;?>
	<!-- blueprint CSS framework -->
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/frontcss/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/frontcss/print.css" media="print" />
	<!--[if lt IE 8]>-->
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/frontcss/ie.css" media="screen, projection" />
	<!--<![endif]-->
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/frontcss/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/frontcss/form.css" />

	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
</head>
<head>
    <style>
        .bretkam {
padding: 7px 14px;
margin: 0 0 18px;
list-style: none;
background-color: #fbfbfb;
background-image: -moz-linear-gradient(top,#fff,#f5f5f5);
background-image: -ms-linear-gradient(top,#fff,#f5f5f5);
background-image: -webkit-gradient(linear,0 0,0 100%,from(#fff),to(#f5f5f5));
background-image: -webkit-linear-gradient(top,#fff,#f5f5f5);
background-image: -o-linear-gradient(top,#fff,#f5f5f5);
background-image: linear-gradient(top,#fff,#f5f5f5);
background-repeat: repeat-x;
border: 1px solid #ddd;
-webkit-border-radius: 3px;
-moz-border-radius: 3px;
border-radius: 3px;
filter: progid:dximagetransform.microsoft.gradient(startColorstr='#ffffff',endColorstr='#f5f5f5',GradientType=0);
-webkit-box-shadow: inset 0 1px 0 #fff;
-moz-box-shadow: inset 0 1px 0 #fff;
box-shadow: inset 0 1px 0 #fff;
}
    </style>
        
  </head>

  <body>
      
    <div class="navbar-wrapper">

      <div class="container">

          <div class="navbar navbar-inverse" style="margin-top: 25px;">
              
          <div class="navbar-inner"style="padding-top: 5px; padding-bottom: 5px;">
              
              <?
        $apps=Setapp::Model()->findAll(array(
        'select'=>'*',
        'condition'=>'id_app=:app',
        'params'=>array(':app'=>1),
        ));
        foreach($apps as $app):
        ?>
              <a class="brand" href="#"><?=$app->namaapp?></a>
        <?endforeach;?>
              
              <div id="mainmenu" style="padding-top: 5px">
                <?php $this->widget('zii.widgets.CMenu',array(
			'items'=>array(
				array('label'=>'Home', 'url'=>array('/site/index')),
				array('label'=>'About', 'url'=>array('/site/page', 'view'=>'about')),
				array('label'=>'Login', 'url'=>array('/site/login'), 'visible'=>Yii::app()->user->isGuest),
				array('label'=>'Logout ('.Yii::app()->user->name.')', 'url'=>array('/site/logout'), 'visible'=>!Yii::app()->user->isGuest)
			),
		)); ?>
              </div>
            </div>
          </div>
     
          <?     $this->widget('bootstrap.widgets.TbCarousel', array(
  'items'=>array(
      array(
		'image'=>'http://localhost/twitterbootstrap.docs/docs/assets/img/examples/slide-01.jpg',
		'label'=>'First Thumbnail label',
		'caption'=>'Cras justo odio, dapibus ac facilisis in, egestas eget quam. ' .
			'Donec id elit non mi porta gravida at eget metus. ' .
			'Nullam id dolor id nibh ultricies vehicula ut id elit.'),
      array(
		'image'=>'http://localhost/twitterbootstrap.docs/docs/assets/img/examples/slide-02.jpg',
		'label'=>'Second Thumbnail label',
		'caption'=>'Cras justo odio, dapibus ac facilisis in, egestas eget quam. ' .
			'Donec id elit non mi porta gravida at eget metus. ' .
			'Nullam id dolor id nibh ultricies vehicula ut id elit.'),
      array(
		'image'=>'http://localhost/twitterbootstrap.docs/docs/assets/img/examples/slide-03.jpg',
		'label'=>'Third Thumbnail label',
		'caption'=>'Cras justo odio, dapibus ac facilisis in, egestas eget quam. ' .
			'Donec id elit non mi porta gravida at eget metus. ' .
			'Nullam id dolor id nibh ultricies vehicula ut id elit.'),
  ),
));?>
          <div class="bretkam">
    <?php if(isset($this->breadcrumbs)):?>
		<?php $this->widget('zii.widgets.CBreadcrumbs', array(
			'links'=>$this->breadcrumbs,
		)); ?><!-- breadcrumbs -->
	<?php endif?>
          </div>
	<?php echo $content; ?>

	<div class="clear"></div>
        </div>
      </div>

    <div class="container marketing">

      <div id="footer">
		<?
        $cright=Setapp::Model()->findAll(array(
        'select'=>'*',
        'condition'=>'id_app=:idapp',
        'params'=>array(':idapp'=>1),
        ));
        foreach($cright as $cr):
        ?>
            <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; <?php echo date('Y'); ?> by <?=$cr->namaapp?>, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        <?endforeach;?>
	</div>
    </div>
  </body>
</html>
