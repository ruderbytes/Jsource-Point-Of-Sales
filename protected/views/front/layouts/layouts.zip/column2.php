<?php $this->beginContent('//layouts/main'); ?>
<div class="span8">
	<div id="content">
		<?php echo $content; ?>
	</div><!-- content -->
</div>
<div class="span3">
	<div id="sidebar">
<?php
$this->beginWidget('bootstrap.widgets.TbBox', array(
	'title' => 'Advertising',
        'headerIcon' => 'icon-home',
        'headerButtons' => array(
	array(
		'class' => 'bootstrap.widgets.TbButtonGroup',
		'type' => 'primary',
		'buttons' => array(
			array('items' => array(
                                array('label' => 'Pasang Iklan', 'url' =>  array('advertising/create')),
			)),
		)
	),
)
));
        $idsup=Supplier::Model()->findAll(array(
        'select'=>'*',
        'order'=>'Id_sup DESC',
        'limit'=>10,
));
        foreach($idsup as $idsuprows): 
        echo CHtml::link($idsuprows->fname." ".$idsuprows->lname,array('supplier/view','id'=>$idsuprows->Id_sup))."<br/>";
 endforeach; 
$this->endWidget();?>

            
            
<?php
$this->beginWidget('bootstrap.widgets.TbBox', array(
	'title' => 'Download',
        'headerIcon' => 'icon-home',
        'headerButtons' => array(
	array(
		'class' => 'bootstrap.widgets.TbButtonGroup',
		'type' => 'primary',
		'buttons' => array(
			array('items' => array(
                                array('label' => 'All Files', 'url' =>  array('download/index')),
			)),
		)
	),
)
));
        $idsup=Supplier::Model()->findAll(array(
        'select'=>'*',
        'order'=>'Id_sup DESC',
        'limit'=>10,
));
        foreach($idsup as $idsuprows): 
        echo CHtml::link($idsuprows->fname." ".$idsuprows->lname,array('supplier/view','id'=>$idsuprows->Id_sup))."<br/>";
 endforeach; 
$this->endWidget();?>

            
	</div><!-- sidebar -->
</div>
<?php $this->endContent(); ?>