BootProgressColumn
==================

Progress Bar Inside GridView Column compatible with 'bootstrap' extension. Original from: http://www.yiiframework.com/wiki/347/bootprogresscolumn-progress-bar-inside-gridview-column-compatible-with-bootstrap-extension/