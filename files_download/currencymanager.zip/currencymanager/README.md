Yii-Currency-Manager-Module
===========================

Simple Currency Manager Module for Yii Framework